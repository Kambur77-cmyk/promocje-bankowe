<?php
header('Content-Type: application/json');
require_once __DIR__ . '/config.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['user' => null]);
    exit;
}

try {
    $stmt = $pdo->prepare('SELECT email, display_name FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(['user' => null]);
        exit;
    }

    echo json_encode([
        'user' => [
            'email' => $user['email'],
            'displayName' => $user['display_name']
        ]
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Błąd serwera']);
}